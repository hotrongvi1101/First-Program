
package midterm;

interface IMotoBike {
    double totalBill();
}
